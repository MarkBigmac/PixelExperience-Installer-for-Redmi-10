----------------------------------------------------------------
!!! If you have a different phone model, then don't even try !!!
----------------------------------------------------------------

If you opened this file, then you either encountered a problem in the console and were directed here, or you are just a person who always reads README files, which, of course, is very good :D

!!! If you want to replace the Pixel Experience image with your ROM, scroll to the 38 line of this file, there are instruction there. !!!

Anyway, here's what you should do if the flashing process doesn't start:

1) Install drivers for your device. You probably unlocked the bootloader on your smartphone yourself using the MiUnlock program. In the folder with this program there is a file "MiUsbDriver.exe ", with the help of it, you can install the drivers. However, if you have already removed MiUnlock, I copied this file in /Folder_With_This_README/platform-tools/help/driver/MiUsbDriver.exe.

2) If you have drivers, or you have installed them right now according to the first point, but you still get an error, you should think about whether your cable is original or not. If it is original, then insert it into another USB port, preferably version 2.0, from the back of your PC. (Directly to the motherboard)
If you have a laptop, just try connecting to USB 2.0 and try again.

3) You REALLY need to unlock the BOOTLOADER. If you haven't done that, then even God won't help you.

4) Try to do everything manually:

4.1) Reboot device in fastboot 
4.2) Connect device to your pc 
4.3) Open cmd (Win+R -> cmd.exe)
4.4) Copy directory "platform-tools" from this folder to C:
4.5) In the cmd enter:

cd C:/platform-tools
fastboot devices
fastboot --disable-verity --disable-verification flash vbmeta vbmeta.img
fastboot reboot fastboot
fastboot flash system system.img
fastboot reboot recovery

4.6) In Recovery select "Wipe Data", confirm it.
4.7) Restart your smartphone and it should start Pixel Experience

That's all, I can't help you any more. Search in Google ;)

------------------------------------------------------------------
INSTRUCTIONS FOR REPLACING THE PIXELEXPERIENCE IMAGE WITH YOUR ROM
------------------------------------------------------------------

1) Download your ROM
!!! THE ANDROID VERSION IN THE IMAGE MUST BE AT LEAST 11, THE ARCHITECTURE MUST BE ARM64-AB, OTHERWISE YOU WILL 100% FAIL !!!

1.1) If you need, download your own vbmeta.img

2) Rename your rom to "system.img"
2.1) Rename your vbmeta to "vbmeta.img", if you want to flash it to

3) Open the "platform-tools" folder from the directory with this README

4) Replace the system.img that is already in the folder with your own system.img
4.3) If you downloaded your own vbmeta.img file, replace it with an existing vbmeta.img file from the folder

5) Start .bat script and enjoy!

!!! Not all GSI images with this architecture run, believe me, I checked. !!!

-------
Sources
-------

https://4pda.to/forum/index.php?showtopic=1042194
https://github.com/ponces/treble_build_pe/releases

-------
Credits
-------

PixelExperience GSI rom: https://github.com/ponces
Script: @LogOffTech
README: @LogOffTech
Release notes: @LogOffTech
Support: You, thank you for finishing reading :3